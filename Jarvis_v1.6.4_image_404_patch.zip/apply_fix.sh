#!/data/data/com.termux/files/usr/bin/bash
set -e

ROOT="$(pwd)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH_DIR="$SCRIPT_DIR/jarvis_v164_patch_files"

if [ -d "$ROOT/app/src/main/java/com/hyperion/jarvis" ]; then
    PROJECT="$ROOT"
elif [ -d "$ROOT/Jarvis/app/src/main/java/com/hyperion/jarvis" ]; then
    PROJECT="$ROOT/Jarvis"
else
    echo "ERROR: Run this from the Jarvis project root, or unzip this patch inside the Jarvis project root then run: bash apply_fix.sh"
    exit 1
fi

if [ ! -d "$PATCH_DIR/app/src/main/java/com/hyperion/jarvis" ]; then
    echo "ERROR: jarvis_v164_patch_files folder missing. Unzip the patch again, then run: bash apply_fix.sh"
    exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PROJECT/jarvis-v1.6.4-image-404-backup-$STAMP"
mkdir -p "$BACKUP/app/src/main/java/com/hyperion/jarvis" "$BACKUP/app"

cp "$PROJECT/app/src/main/java/com/hyperion/jarvis/MainActivity.java" "$BACKUP/app/src/main/java/com/hyperion/jarvis/MainActivity.java"
cp "$PROJECT/app/src/main/java/com/hyperion/jarvis/JarvisCommandCenter.java" "$BACKUP/app/src/main/java/com/hyperion/jarvis/JarvisCommandCenter.java"
cp "$PROJECT/app/build.gradle" "$BACKUP/app/build.gradle"

cp "$PATCH_DIR/app/src/main/java/com/hyperion/jarvis/MainActivity.java" "$PROJECT/app/src/main/java/com/hyperion/jarvis/MainActivity.java"
cp "$PATCH_DIR/app/src/main/java/com/hyperion/jarvis/JarvisCommandCenter.java" "$PROJECT/app/src/main/java/com/hyperion/jarvis/JarvisCommandCenter.java"
cp "$PATCH_DIR/app/build.gradle" "$PROJECT/app/build.gradle"

echo "Jarvis v1.6.4 image 404 patch applied."
echo "Backup saved at: $BACKUP"
echo "Now rebuild in AIDE, or run your existing Gradle build command."
